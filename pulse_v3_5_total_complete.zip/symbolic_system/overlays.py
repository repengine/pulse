from simulation_engine.worldstate import WorldState
from simulation_engine.state_mutation import adjust_overlay

OVERLAY_NAMES = ["hope", "despair", "rage", "fatigue", "trust"]

def get_overlay_value(state: WorldState, name: str) -> float:
    return getattr(state.overlays, name, 0.0)

def is_overlay_dominant(state: WorldState, name: str, threshold: float = 0.65) -> bool:
    return get_overlay_value(state, name) >= threshold

def boost_overlay(state: WorldState, name: str, amount: float = 0.02):
    adjust_overlay(state, name, amount)

def suppress_overlay(state: WorldState, name: str, amount: float = 0.02):
    adjust_overlay(state, name, -amount)

def reinforce_synergy(state: WorldState, trigger: str, affected: str, factor: float = 0.01):
    if is_overlay_dominant(state, trigger):
        adjust_overlay(state, affected, factor)
        state.log_event(f"Symbolic synergy: {trigger} boosted {affected} by {factor:.3f}")

def apply_overlay_interactions(state: WorldState):
    reinforce_synergy(state, "hope", "trust", factor=0.01)
    if is_overlay_dominant(state, "rage"):
        suppress_overlay(state, "trust", amount=0.015)
    reinforce_synergy(state, "despair", "fatigue", factor=0.015)
    if is_overlay_dominant(state, "fatigue"):
        suppress_overlay(state, "hope", amount=0.02)