from simulation_engine.worldstate import WorldState
from typing import Dict

def get_overlay_snapshot(state: WorldState) -> Dict[str, float]:
    return state.overlays.as_dict()

def normalize_overlay_vector(overlays: Dict[str, float]) -> Dict[str, float]:
    total = sum(overlays.values())
    if total == 0:
        return {k: 0.0 for k in overlays}
    return {k: v / total for k, v in overlays.items()}

def symbolic_tension_score(overlays: Dict[str, float]) -> float:
    h, d, r, f, t = (
        overlays.get("hope", 0),
        overlays.get("despair", 0),
        overlays.get("rage", 0),
        overlays.get("fatigue", 0),
        overlays.get("trust", 0),
    )
    tension = (h * d) + (r * t) + (f * h * 0.5)
    return round(tension, 3)

def symbolic_fragility_index(state: WorldState) -> float:
    overlays = get_overlay_snapshot(state)
    tension = symbolic_tension_score(overlays)
    fragility = tension
    if overlays.get("trust", 0.5) < 0.3:
        fragility += overlays.get("despair", 0) * 0.5
        fragility += overlays.get("rage", 0) * 0.4
    return round(min(fragility, 1.0), 3)