from typing import Dict, List
import datetime

PFPA_ARCHIVE: List[Dict] = []

def log_forecast_to_pfpa(forecast_obj: Dict, outcome: Dict = None, status: str = "open"):
    entry = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "trace_id": forecast_obj.get("trace_id"),
        "origin_turn": forecast_obj.get("origin_turn"),
        "horizon_days": forecast_obj.get("horizon_days"),
        "fragility": forecast_obj.get("fragility"),
        "confidence": forecast_obj.get("confidence"),
        "alignment": forecast_obj.get("alignment", {}),
        "symbolic_snapshot": forecast_obj["forecast"]["symbolic_change"],
        "exposure_start": forecast_obj["forecast"]["start_capital"],
        "exposure_end": forecast_obj["forecast"]["end_capital"],
        "status": status,
        "outcome": outcome or {},
    }
    PFPA_ARCHIVE.append(entry)

def get_latest_forecasts(n: int = 5) -> List[Dict]:
    return PFPA_ARCHIVE[-n:]