from typing import Dict, Any
from dataclasses import dataclass, field
import copy

@dataclass
class SymbolicOverlay:
    hope: float = 0.5
    despair: float = 0.5
    rage: float = 0.5
    fatigue: float = 0.5
    trust: float = 0.5

    def as_dict(self):
        return {
            "hope": self.hope,
            "despair": self.despair,
            "rage": self.rage,
            "fatigue": self.fatigue,
            "trust": self.trust,
        }

@dataclass
class CapitalExposure:
    nvda: float = 0.0
    msft: float = 0.0
    ibit: float = 0.0
    spy: float = 0.0
    cash: float = 100000.0

    def as_dict(self):
        return {
            "nvda": self.nvda,
            "msft": self.msft,
            "ibit": self.ibit,
            "spy": self.spy,
            "cash": self.cash,
        }

@dataclass
class WorldState:
    turn: int = 0
    variables: Dict[str, Any] = field(default_factory=dict)
    overlays: SymbolicOverlay = field(default_factory=SymbolicOverlay)
    capital: CapitalExposure = field(default_factory=CapitalExposure)
    log: list = field(default_factory=list)

    def clone(self):
        return copy.deepcopy(self)

    def increment_turn(self):
        self.turn += 1
        self.log.append(f"Turn advanced to {self.turn}")

    def update_variable(self, name: str, value: Any):
        self.variables[name] = value
        self.log.append(f"Variable '{name}' set to {value}")

    def get_variable(self, name: str, default: Any = None) -> Any:
        return self.variables.get(name, default)

    def snapshot(self) -> Dict[str, Any]:
        return {
            "turn": self.turn,
            "variables": self.variables.copy(),
            "overlays": self.overlays.as_dict(),
            "capital": self.capital.as_dict(),
        }

    def log_event(self, msg: str):
        self.log.append(msg)

    def get_log(self, last_n: int = 10):
        return self.log[-last_n:]