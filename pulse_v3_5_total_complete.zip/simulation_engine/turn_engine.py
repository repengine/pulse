from simulation_engine.state_mutation import decay_overlay
from typing import Callable, Optional
from simulation_engine.worldstate import WorldState

def run_turn(
    state: WorldState,
    rule_fn: Optional[Callable[[WorldState], None]] = None,
    decay_rate: float = 0.01,
):
    state.increment_turn()
    for overlay_name in ["hope", "despair", "rage", "fatigue", "trust"]:
        decay_overlay(state, overlay_name, rate=decay_rate)
    if rule_fn:
        rule_fn(state)
    state.log_event(f"Turn {state.turn} completed.")