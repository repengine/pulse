from typing import List, Dict, Optional

class ForecastMemory:
    def __init__(self):
        self._memory: List[Dict] = []

    def store(self, forecast_obj: Dict):
        self._memory.append(forecast_obj)

    def get_recent(self, n: int = 5) -> List[Dict]:
        return self._memory[-n:]

    def get_by_trace_id(self, trace_id: str) -> Optional[Dict]:
        for f in reversed(self._memory):
            if f.get("trace_id") == trace_id:
                return f
        return None

    def get_by_symbolic_condition(self, key: str, threshold: float = 0.5) -> List[Dict]:
        results = []
        for f in self._memory:
            symbolic = f.get("forecast", {}).get("symbolic_change", {})
            if symbolic.get(key, 0) > threshold:
                results.append(f)
        return results

    def clear(self):
        self._memory.clear()