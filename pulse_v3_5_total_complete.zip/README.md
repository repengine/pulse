Pulse v3.5: Strategic foresight simulation system.
Run: `python main.py`