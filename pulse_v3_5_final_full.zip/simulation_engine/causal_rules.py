from simulation_engine.state_mutation import adjust_overlay, update_numeric_variable, adjust_capital
from simulation_engine.worldstate import WorldState

def apply_causal_rules(state: WorldState):
    if state.overlays.hope > 0.7 and state.overlays.fatigue < 0.3:
        adjust_overlay(state, "trust", +0.02)
        update_numeric_variable(state, "hope_surge_count", +1, max_val=100)
    if state.overlays.despair > 0.6:
        adjust_overlay(state, "fatigue", +0.015)
    if state.overlays.despair > 0.5:
        adjust_overlay(state, "hope", -0.01)
    if state.overlays.trust > 0.6:
        adjust_capital(state, "nvda", +500)
    if state.overlays.fatigue > 0.75:
        adjust_capital(state, "ibit", -250)