def format_forecast_tile(forecast_obj: dict) -> str:
    f = forecast_obj
    fc = f["forecast"]
    alignment = f.get("alignment", {})
    fragility = f.get("fragility", "N/A")
    confidence = f.get("confidence", "pending")

    formatted = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔮 Strategos Forecast Tile
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Duration      : {f['horizon_days']} days
Turn          : {f['origin_turn']}
Trace ID      : {f['trace_id']}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Exposure Delta:
  NVDA  → {fc['end_capital']['nvda'] - fc['start_capital']['nvda']:.2f}
  MSFT  → {fc['end_capital']['msft'] - fc['start_capital']['msft']:.2f}
  IBIT  → {fc['end_capital']['ibit'] - fc['start_capital']['ibit']:.2f}
  SPY   → {fc['end_capital']['spy'] - fc['start_capital']['spy']:.2f}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Fragility     : {fragility}
Confidence    : {confidence}
Alignment     : {alignment.get('bias', 'N/A')}
Status        : {f.get('status', 'unlabeled')}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    return formatted.strip()