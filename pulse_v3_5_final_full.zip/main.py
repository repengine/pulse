from simulation_engine.worldstate import WorldState
from simulation_engine.turn_engine import run_turn
from simulation_engine.causal_rules import apply_causal_rules
from forecast_output.forecast_generator import generate_forecast
from forecast_output.pfpa_logger import log_forecast_to_pfpa
from memory.forecast_memory import ForecastMemory
from operator_interface.strategos_digest import generate_strategos_digest

def run_pulse_simulation(turns: int = 5):
    print("\n🌐 Initializing Pulse v3.5...\n")
    state = WorldState()
    memory = ForecastMemory()
    for _ in range(turns):
        print(f"\n🔄 Running Turn {state.turn + 1}...")
        run_turn(state, rule_fn=apply_causal_rules)
        forecast = generate_forecast(state, horizon_days=2)
        memory.store(forecast)
        log_forecast_to_pfpa(forecast)
    print("\n📘 Generating Strategos Digest...\n")
    digest = generate_strategos_digest(memory, n=min(turns, 5))
    print(digest)

if __name__ == "__main__":
    run_pulse_simulation(turns=5)